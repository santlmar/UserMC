export interface ITokenPayload {
  id: number;
  iat: number;
  exp: number;
}
