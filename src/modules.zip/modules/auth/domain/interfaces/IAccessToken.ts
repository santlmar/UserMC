export interface IAccessToken {
  access_token: string;
}
