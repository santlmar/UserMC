import { Injectable, RequestTimeoutException } from "@nestjs/common";
import { IUserService } from "../../domain/service/IUser.service";
import { IUser, IUserCreate, IUserUpdate } from "../../domain/interfaces/IUser";
import { InjectRepository } from "@nestjs/typeorm";
import { User } from "../entity/user.entity";
import { Repository } from "typeorm";
import { NotFoundError } from "rxjs";

@Injectable()
export class UserService implements IUserService {
      constructor(
        @InjectRepository(User) 
        private readonly userRepository: Repository<User>,
      ) {}

      
    async update(id: IUser["id"], pastUser: IUserUpdate):Promise<boolean> {
      const user = await this.get(id);
 
      try {
        pastUser.auth = pastUser?.auth
        ? {
          ...user.auth,
          email: pastUser?.auth?.email || user.auth.email,
          password: pastUser?.auth?.password || user.auth.password,
        }
        : user.auth;
        console.log('userToUpdate', pastUser);
        await this.userRepository.save({
          ...user,
          ...pastUser,
        });
      } catch (error) {
        throw new RequestTimeoutException('Error updating User')
      }
      return true;
    }

    async create(userDto: IUserCreate): Promise<IUser> {
      let user: User | undefined;
      console.log(user)
      try {
        user = this.userRepository.create(userDto);
      } catch (error) {
        throw new RequestTimeoutException('Cannot create user', {
          description: 'Error creating user',
        });
      }
      console.log(user)
      return user;
    }

  async get(id: IUser['id']): Promise<IUser> {
    const User = await this.userRepository.findOneBy({ id });
    if (!User) {
      throw new NotFoundError('User not found');
    }
    return User;
  }

  
}