import { Module } from "@nestjs/common";
import { UserController } from "./infrastructure/controller/user.controller";
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from "./infrastructure/entity/user.entity";
import { UserService } from "./infrastructure/service/user.service";
import { GetUserUseCase } from "./application/getUser/GetUser.useCase";
import { CreateUserUseCase } from "./application/createUser/CreateUser.useCase";
import { UpdateUserUseCase } from "./application/updateUser/UpdateUser.useCase";

@Module({
    controllers: [UserController],
      imports: [TypeOrmModule.forFeature([User])],
      providers: [
        {
            provide: 'UserService',
            useClass: UserService,
        },
        {
          provide: 'GetUserUseCase',
          useClass: GetUserUseCase,
        },
        {
          provide: 'CreateUserUseCase',
          useClass: CreateUserUseCase,
        },
        {
          provide: 'UpdateUserUseCase',
          useClass: UpdateUserUseCase,
        },
      ]
})
export class UserModule {}